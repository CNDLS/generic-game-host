/* Scripts for the Demo game. */


/*
 * Gorge Scene. Places Knights and King, Old Man. 
 * Responds to user's Answers by animating characters into the Gorge.
 */


/* FAILSAFES */
Game = Game || function () {};
Game.Scene = Game.Scene || {};

Game.Scene.Gorge = function (backdrop_spec, set_piece_specs, game) {
	Util.extend_properties(this, new Game.Scene.Basic(backdrop_spec, set_piece_specs, game));
}
$.extend(Game.Scene.Gorge.prototype, Game.Scene.Basic.prototype);

Game.Scene.Gorge.prototype.setup = function (evt, obj) {
	Game.Scene.Basic.prototype.setup.call(this, evt, obj, "gorge");
}